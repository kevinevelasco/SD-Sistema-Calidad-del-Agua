package com.example.Monitores;

public enum Tipos {
    TEMPERATURA, PH, OXIGENO
}
